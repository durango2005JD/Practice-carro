var carro = document.querySelector('.auto')
var llantas = document.querySelector('.rueda')
var humo = document.querySelector('.humoo')
var luz = document.querySelector('.luz')
var fondo = document.querySelector('.fonde')
var llanta2 = document.querySelector('.rueda2')

llantas.addEventListener('click',movimiento)
carro.addEventListener('click',movimiento )
fondo.addEventListener('click',movimiento)
llanta2.addEventListener('click', movimiento )
fondo
function movimiento (){
llantas.classList.add('rueda_animacion')
fondo.classList.add('fondoa')
llanta2.classList.add('rueda2_animation')
luz.classList.remove('oculto')
humo.classList.remove('oculto')
}